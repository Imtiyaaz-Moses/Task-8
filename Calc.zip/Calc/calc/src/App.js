// This is importing the react components from react, the css, and the other components to make the app function.
import React, { Component } from 'react';
import './App.css';
import Res from './Components/Res';
import Calc from './Components/Calc';

// This is the component that will function the calculator properly.
class App extends Component {
    constructor() {
        super();

        this.state = {
            result: ""
        }
    }

    onClick = button => {

        if (button === "=") {
            this.calculate()
        } else if (button === "C") {
            this.reset()
        } else if (button === "CE") {
            this.backspace()
        } else {
            this.setState({
                result: this.state.result + button
            })
        }
    };


    calculate = () => {
        var checkResult = ''
        if (this.state.result.includes('--')) {
            checkResult = this.state.result.replace('--', '+')
        } else {
            checkResult = this.state.result
        }

        try {
            this.setState({
                // eslint-disable-next-line
                result: (eval(checkResult) || "") + ""
            })
        } catch (e) {
            this.setState({
                result: "error"
            })

        }
    };

    reset = () => {
        this.setState({
            result: ""
        })
    };

    backspace = () => {
        this.setState({
            result: this.state.result.slice(0, -1)
        })
    };

    render() {
        return (
            <div className="App">
                <div className="calculator-body">
                    <h3 id="h3">This is a Simple Calculator</h3>
                    <Res result={this.state.result}/>
                    <Calc onClick={this.onClick}/>
                </div>
            </div>
            // In the div above, the components are being called as well as a h3 tag.
        );
    }
}

export default App;