// This is importing the react components from react.
import React, {Component} from 'react';

// This is the component that will render the results.
class Res extends Component {
    render() {
        let {result} = this.props;
        return (
            <div className="result">
                <p>{result}</p>
            </div>
        );
    }
}


export default Res;