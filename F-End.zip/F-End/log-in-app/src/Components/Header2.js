// This is importing the components needed to make the app work.
// React and the menu component from the components folder are being imported.
import React from 'react';
import SimpleMenuui from './Menuui';

// This is the header function. It will display a logo, company name and slogan. It will also contain the menu button.

function Header2(props) {
    return (<header className="App-header">
    	<br/>
		<h1><img id="logo" src="./goons.png" alt="Logo"/>Welcome to Goonzquad</h1>
		<h3>Simply Built</h3>
		<h4>You Love To Build?</h4><br/>
		<SimpleMenuui/>
		</header>);
}

export default Header2;