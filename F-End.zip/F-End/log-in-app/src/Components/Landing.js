import React from 'react';
import '../App.css';

function LandingPage(props) {
    return (<div className="App-land"><p>If you love to keep it original, this is not for you!<br/>If you love to build it, you're in the right spot.<br/>
    	From stock to extremely modified, we love to mark our rigs as "Simply Built"</p>
    	<p>We rebuild/salvage smashed up vehicles. We turn these vehicles into, vehicles that are better than OEM(Original Equipment Manufacturer.)<br/><strong>Dude, that's legit!</strong><br/>
    	We've been doing this since 2015, and have worked on a couple of major projects. Our vehicles below are for sale:</p></div>);
}

export default LandingPage;