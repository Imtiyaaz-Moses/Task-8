// This is importing the components needed to make the app work.
// React, CSS, Bootstrap, and some components from the components folder are being imported.
import React from 'react';
import '../App.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Header3 from './Header3';
import bull from '../Images/bull1.jpg';
import kitty from '../Images/kitty1.jpg';
import ponys from '../Images/stang.jpg';
import bull2 from '../Images/bull2.jpg';
import kitty2 from '../Images/kitty.jpg';
import ponys2 from '../Images/stang2.jpg';

function Sale(props) {
    return (
// This(link tag) is inserting bootstrap, so its components can work and function properly.
      <sale className="App-sale">
          <link
  rel="stylesheet"
  href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css"
  integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS"
  crossorigin="anonymous"
/>
      <Header3/>
    	<h2 id="kit2">2017 Lamborghini Huracán LP 580-2:</h2>
    	<br/>
    	<Container>
        <Row>
          <Col sm={{ size: 'auto', offset: 100 }}><img src={bull} alt="Lamborghini"/><br/><br/><p id="kit">Before.</p><br/></Col>
          <Col sm={{ size: 'auto', offset: 100 }}><img src={bull2} alt="Lamborghini2"/><br/><br/><p id="kit">After.</p><br/></Col>
          <Col sm={{ size: 'auto', offset: 100 }}><br/><p id="kit">Our 2017 Lamborghini Huracán LP 580-2, came from Miami Florida, with damage to the front-end of the car. 
          It has always been a dream to own a Lamborghini, and this has made it happen. We've took this car from wrecked and turned it back to it's glory. 
          If you are interested to buy this vehicle it will cost : <br/><i>R3 500 000.00</i><br/> excluding delivery cost. Being a supercar, delivery insurance will be included.</p><br/></Col>
        </Row>
        </Container>
        <br/>
        <h2 id="kit2">2017 Dodge Challenger Hellcat:</h2>
        <br/>
        <Container>
        <Row>
          <Col sm={{ size: 'auto', offset: 0 }}><img src={kitty} alt="Dodge"/><br/><br/><p id="kit">Before.</p><br/></Col>
          <Col sm={{ size: 'auto', offset: 0 }}><img src={kitty2} alt="Dodge2"/><br/><br/><p id="kit">After.</p><br/></Col>
          <Col sm={{ size: 'auto', offset: 0 }}><br/><p id="kit">The 2017 Dodge Challenger Hellcat, bought with extensive frame damage, as well as the side quarter panel bent, has been fully restored. 
          Fitted with a Valve-tronic Armytrix exhaust, this kitty prrrs. 
          If you are interested to buy this vehicle it will cost : <br/><i>R1 500 000.00</i><br/> excluding delivery cost. Being a muscle car, delivery insurance will be included.</p><br/></Col>
        </Row>
        </Container>
        <br/>
        <h2 id="kit2">2017 Ford Mustang 5.0 GT:</h2>
        <br/>
        <Container>
        <Row>
          <Col sm={{ size: 'auto', offset: 0 }}><img src={ponys} alt="Ford"/><br/><br/><p id="kit">Before.</p><br/></Col>
          <Col sm={{ size: 'auto', offset: 0 }}><img src={ponys2} alt="Ford2"/><br/><br/><p id="kit">After.</p><br/></Col>
          <Col sm={{ size: 'auto', offset: 0 }}><br/><p id="kit">2017 Ford Mustang 5.0 GT, our first major rebuild. Bought at Copart in Chattanooga, Tennessee, had been wrecked all round, from front to back. 
          Fitted with custom bumpers, spoiler and a Valve-tronic Armytrix exhaust, this pony rips like 'Freedom.' 
          If you are interested to buy this vehicle it will cost : <br/><i>R1 125 000.00</i><br/> excluding delivery cost. Being a muscle car, delivery insurance will be included.</p><br/></Col>
        </Row>
		</Container></sale>);
    // Above are coloumns, which have pictures, and paragraphs, displaying the items.
}

export default Sale;