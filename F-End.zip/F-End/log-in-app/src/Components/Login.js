// This is importing the components needed to make the app work.
import React from 'react';
import '../App.css';

// This function will display a message when the user is logged in or not.
function UserGreeting(props) {
    return <p id="menuit">Welcome back!</p>;
}

// This function will display a message when the user is logged in or not.
function GuestGreeting(props) {
    return <p id="menuit">Please sign up.</p>;
}

function Greeting(props) {
    const isLoggedIn = props.isLoggedIn;
    if (isLoggedIn) {
        return <UserGreeting />;
    }
    return <GuestGreeting />;
}

// This function is the button, in which the user will click to be logged in.
function LoginButton(props) {
    return (
        <button id="menuit" onClick={props.onClick}>
      Login
    </button>
    );
}

// This function is the button, in which the user will click to be logged out.
function LogoutButton(props) {
    return (
        <button id="menuit" onClick={props.onClick}>
      Logout
    </button>
    );
}

// This will state whether the user is still currently logged in or logged out. The output will be calclated and displayed.
class LoginControl extends React.Component {
    constructor(props) {
        super(props);
        this.handleLoginClick = this.handleLoginClick.bind(this);
        this.handleLogoutClick = this.handleLogoutClick.bind(this);
        this.state = { isLoggedIn: false };
    }

    handleLoginClick() {
        this.setState({ isLoggedIn: true });
    }

    handleLogoutClick() {
        this.setState({ isLoggedIn: false });
    }

    render() {
        const isLoggedIn = this.state.isLoggedIn;
        let button;

        if (isLoggedIn) {
            button = <LogoutButton onClick={this.handleLogoutClick} />;
        } else {
            button = <LoginButton onClick={this.handleLoginClick} />;
        }

        return (
            <div>
        <Greeting isLoggedIn={isLoggedIn} />
        {button}
      </div>
        );
    }
}

export default LoginControl;