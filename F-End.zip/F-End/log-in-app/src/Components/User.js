// This is importing the components needed to make the app work.
// React, CSS, React-Router-Dom and the header component from the components folder are being imported.
import React from 'react';
import '../App.css';
import { Route, Link } from 'react-router-dom';
import Header2 from './Header2';

const User = ({ match }) => <p>{match.params.id}</p>

class UsersPage extends React.Component {
    render() {
        return (
// This(link tag) is inserting bootstrap, so its components can work and function properly.
            <div className="App">
                <link
  rel="stylesheet"
  href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css"
  integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS"
  crossorigin="anonymous"
/>
            <Header2/>
        <h1 id="kit">User Profile</h1>
        <h3 id="kit">Select a user profile.</h3>
        <ul>
          <li>
            <Link to="/User/You're on user profile 1 : Usr_1">User profile 1 </Link>
          </li>
          <li>
            <Link to="/User/You're on user profile 2 : Usr_2">User profile 2 </Link>
          </li>
          <li>
            <Link to="/User/You're on user profile 3 : Usr_3">User profile 3 </Link>
          </li>
          <li>
            <Link to="/User/You're on user profile 4 : Usr_4">User profile 4 </Link>
          </li>
          <li>
            <Link to="/User/You're on user profile 5 : Usr_5">User profile 5 </Link>
          </li>
        </ul>
        <Route path="/User/:id" component={User} />
      </div>
      // These links in the unordered list are, that will switch the users profile to the desired profile that they want to be on.
        )
    }
}
export default UsersPage;