// React and the css for this file is being called.
import React from 'react';
import '../App.css'

// This is a simple function of tags that will be exported to be displayed.
function Header(props) {
    return (<header className="App-header"><h3>To-Do List:</h3></header>);
}
export default Header;