import React, { useState } from 'react';
import './App.css';
import Header from './Components/Header';

function Todo({ todo, index, completeTodo, removeTodo }) {
    return (
        // The tags in here will style the task item. When the user clicks on the 'completed' button, a line will be displayed through the task item.
        <div
      className="todo"
      style={{ textDecoration: todo.isCompleted ? "line-through" : "" }}
    >
      {todo.text}
      <div>
        <button onClick={() => completeTodo(index)}>Complete</button>
        <button onClick={() => removeTodo(index)}>x</button>
      </div>
    </div>
        // This div contains the buttons, that the user will click when they have completed a task and want to remove it.
    );
}

function TodoForm({ addTodo }) {
    const [value, setValue] = useState("");

    // A synthetic handling event is being used, so that an event-listener does not have to be used.
    const handleSubmit = e => {
        e.preventDefault();
        if (!value) return;
        addTodo(value);
        setValue("");
    };

    return (
        <form onSubmit={handleSubmit}>
      <input
        type="text"
        className="input"
        value={value}
        onChange={e => setValue(e.target.value)}
      />
    </form>
    );
}

// In this function, example tasks are being displayed.
function App() {
    const [todos, setTodos] = useState([{
            text: "Complete task 8.1",
            isCompleted: false
        },
        {
            text: "Complete task 8.2",
            isCompleted: false
        },
        {
            text: "Complete task 8.3",
            isCompleted: false
        }
    ]);

    // This will allow the user to add new tasks.
    const addTodo = text => {
        const newTodos = [...todos, { text }];
        setTodos(newTodos);
    };

    // This will allow the user to select complete task, and it'll draw a line through the task.
    const completeTodo = index => {
        const newTodos = [...todos];
        newTodos[index].isCompleted = true;
        setTodos(newTodos);
    };

    // This will allow the user to remove a task, completed or not.
    const removeTodo = index => {
        const newTodos = [...todos];
        newTodos.splice(index, 1);
        setTodos(newTodos);
    };

    // This will display the items on the page.
    return (
        <div className="app">
    <Header/>
      <div className="todo-list">
        {todos.map((todo, index) => (
          <Todo
            key={index}
            index={index}
            todo={todo}
            completeTodo={completeTodo}
            removeTodo={removeTodo}
          />
        ))}
        <TodoForm addTodo={addTodo} />
      </div>
    </div>
    );
}

export default App;